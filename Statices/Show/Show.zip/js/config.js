// JavaScript Document

var gpath = {
       static_path: "http://statices.dssfxt.net/",
    show_path: "http://www.dssfxt.net/",
    management_path: "http://management.dssfxt.net/",
    market_path:"http://market.dssfxt.net/"
}